import type { Product } from "@/lib/product";

/** One slot in a look card (top, bottom, etc.) */
export type LookPieceRole = "top" | "bottom" | "outer" | "shoes" | "bag";

export type LookPiece = {
  role: LookPieceRole;
  label: string;
  product: Product | null;
};

export type StylingLook = {
  id: string;
  title: string;
  /** Short reason shown at the top of the card */
  reason: string;
  context?: string;
  pieces: LookPiece[];
};

export type StylingLookDef = {
  id: string;
  title: string;
  reason: string;
  context?: string;
  /** Per-slot search query */
  queries: Partial<Record<LookPieceRole, string>>;
};

const ROLE_LABELS: Record<LookPieceRole, string> = {
  top: "Top",
  bottom: "Bottom",
  outer: "Outer",
  shoes: "Shoes",
  bag: "Bag",
};

export const HOME_LOOK_DEFS: readonly StylingLookDef[] = [
  {
    id: "rain-commute",
    title: "Rainy day commute",
    reason: "Water-resistant outer and dark bottoms to streamline the silhouette",
    context: "Commute · Rain",
    queries: {
      outer: "women trench coat",
      top: "women knit sweater",
      bottom: "women slacks",
      shoes: "women loafers",
    },
  },
  {
    id: "weekend-date",
    title: "Weekend date",
    reason: "Soft knit and A-line skirt to balance proportions",
    context: "Date · Weekend",
    queries: {
      top: "women knit sweater",
      bottom: "women midi skirt",
      shoes: "women loafers",
      bag: "women shoulder bag",
    },
  },
  {
    id: "minimal-daily",
    title: "Minimal daily",
    reason: "Beige and white layers aligned with your saved knit mood",
    context: "Daily",
    queries: {
      top: "women cashmere knit",
      bottom: "women wide pants",
      shoes: "women sneakers",
    },
  },
  {
    id: "layer-travel",
    title: "In-flight layers",
    reason: "Light outer layers for cabin-to-arrival temperature swings",
    context: "Travel",
    queries: {
      outer: "women jacket",
      top: "women sweatshirt",
      bottom: "women jogger pants",
      shoes: "women sneakers",
    },
  },
] as const;

export function lookDefToEmptyLook(def: StylingLookDef): StylingLook {
  const roles = Object.keys(def.queries) as LookPieceRole[];
  return {
    id: def.id,
    title: def.title,
    reason: def.reason,
    context: def.context,
    pieces: roles.map((role) => ({
      role,
      label: ROLE_LABELS[role],
      product: null,
    })),
  };
}

export function mergeLookProducts(
  def: StylingLookDef,
  byRole: Partial<Record<LookPieceRole, Product | null>>
): StylingLook {
  const roles = Object.keys(def.queries) as LookPieceRole[];
  return {
    id: def.id,
    title: def.title,
    reason: def.reason,
    context: def.context,
    pieces: roles.map((role) => ({
      role,
      label: ROLE_LABELS[role],
      product: byRole[role] ?? null,
    })),
  };
}
