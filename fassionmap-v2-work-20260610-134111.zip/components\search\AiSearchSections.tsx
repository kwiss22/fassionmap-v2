"use client";

import { ProductCard } from "@/components/ProductCard";
import type { AiContentArticle, AiLookBrief, AiSearchCuratedItem } from "@/lib/ai/types";
import { productDedupeKey } from "@/lib/product";
import { cn } from "@/lib/utils";

function SectionLabel({
  children,
  className,
}: {
  children: string;
  className?: string;
}) {
  return (
    <h3
      className={cn(
        "text-[11px] font-medium tracking-[0.24em] text-on-surface-variant",
        className
      )}
    >
      {children}
    </h3>
  );
}

function sourceLabel(source: AiContentArticle["source"]): string {
  return source === "news" ? "NEWS" : "BLOG";
}

export function AiArticlesSection({ articles }: { articles: AiContentArticle[] }) {
  if (articles.length === 0) {
    return null;
  }

  return (
    <section className="flex flex-col gap-2 border-t border-outline-variant/40 pt-8">
      <SectionLabel className="text-[10px] tracking-[0.2em] text-on-surface-variant/80">
        Related reads
      </SectionLabel>
      <p className="text-[10px] text-on-surface-variant/70">
        Some sources may be in Korean — especially for K-Fashion stories.
      </p>
      <ul className="mt-1 flex flex-col gap-2">
        {articles.map((article) => (
          <li key={article.link}>
            <a
              href={article.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group block py-1"
            >
              <span className="text-[9px] tracking-[0.16em] text-on-surface-variant/80">
                {sourceLabel(article.source)}
                {article.pubDate ? ` · ${article.pubDate}` : ""}
              </span>
              <p className="mt-0.5 text-[12px] leading-snug text-on-surface-variant transition-colors group-hover:text-on-surface">
                {article.title}
              </p>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}

function buildLookMeta(brief: AiLookBrief): string {
  const parts = [
    brief.whereFrom,
    brief.brandOrItem,
    brief.priceNote,
    brief.shoppingPriceRange,
  ].filter(Boolean);
  return parts.join(" · ");
}

export function AiLookBriefSection({ brief }: { brief: AiLookBrief }) {
  const meta = buildLookMeta(brief);

  return (
    <section className="flex flex-col gap-4">
      <SectionLabel>Your look</SectionLabel>
      <h3 className="editorial-display max-w-2xl text-[26px] leading-tight text-on-surface sm:text-[32px]">
        {brief.headline}
      </h3>
      <p className="max-w-2xl text-[14px] leading-[1.7] text-on-surface-variant">
        {brief.editorialSummary}
      </p>
      {meta ? (
        <p className="max-w-2xl text-[11px] leading-relaxed text-on-surface-variant/90">
          {meta}
        </p>
      ) : null}
    </section>
  );
}

export function AiProductsSection({ items }: { items: AiSearchCuratedItem[] }) {
  if (items.length === 0) {
    return (
      <section className="flex flex-col gap-3">
        <SectionLabel>Shop picks</SectionLabel>
        <p className="py-6 text-center text-[13px] text-on-surface-variant">
          No matching products found.
        </p>
      </section>
    );
  }

  return (
    <section className="flex flex-col gap-4">
      <SectionLabel>Shop picks</SectionLabel>
      <div className="grid grid-cols-2 gap-x-5 gap-y-12 sm:grid-cols-3 lg:grid-cols-4 lg:gap-x-6">
        {items.map((entry, i) => (
          <div key={productDedupeKey(entry.product)} className="flex flex-col gap-3">
            <ProductCard product={entry.product} priority={i === 0} />
            <p className="text-[12px] leading-relaxed text-on-surface-variant">
              <span className="font-medium text-[var(--color-ai)]">Why</span>{" "}
              {entry.reason}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
